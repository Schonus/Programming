# 暗黑斩游戏制作演示 - Cocos Creator制造

[「暗黑斩」](http://www.veewo.com/games/?name=darkslash)是由 Veewo Game 开发的畅销动作游戏，本项目是 Cocos Creator 开发团队使用暗黑斩的原版美术资源在 Cocos Creator 中开发的范例游戏，所有资源已获得 [Veewo Game](http://www.veewo.com/) 团队的授权，在此特别感谢！关于本项目中美术资源的使用授权问题，请务必阅读[资源授权声明](LICENSE.md)。

## AnySDK 接入演示

请切换到 [anysdk](https://github.com/cocos-creator/tutorial-dark-slash/tree/anysdk) 分支来查看。


## 资源授权声明

[「暗黑斩」](http://www.veewo.com/games/?name=darkslash)是由 Veewo Game 开发的畅销动作游戏，本项目是和 Veewo Game 合作的 Cocos Creator 教学游戏项目。其中所有的美术和音效资源（包括但不限于 png, jpg 格式的图片文件和 mp3 格式的音效文件）的版权归 Veewo Game 所有，在未经授权的情况下：

不可在任何情况下用于公开发布的可获取商业利益的游戏或演示。
对本项目中的美术资源进行修改、加工、混合后的图像不可用于再次分发。
在非可获得商业利益的游戏或演示中使用这些资源，需要在软件公开的部分保留本授权声明文本。
除了个人学习研究目的，本授权声明不保证你能获得任何使用本项目资源的授权。如果有任何疑问请咨询触控科技相关部门：contactus@chukong-inc.com

