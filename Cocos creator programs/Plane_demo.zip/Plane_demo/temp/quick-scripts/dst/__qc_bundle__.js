
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/resources/script/Background');
require('./assets/resources/script/Button');
require('./assets/resources/script/EnemyManager');
require('./assets/resources/script/Game');
require('./assets/resources/script/Player');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '68b8bWeh6hKN7B/9QkAAK7e', 'Player');
// resources/script/Player.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //定义飞机速度
        _this.speedX = 0;
        _this.speedY = 0;
        return _this;
    }
    Player.prototype.onLoad = function () {
        var self = this;
        //————————————————————飞机移动部分——————————————————————
        // 设定函数操作
        var func1 = function (event) {
            // 判断输入的是哪个键
            switch (event.keyCode) {
                case 37: //左键
                case 65: //a
                    self.speedX = -200;
                    break;
                case 39: //右键
                case 68: //d
                    self.speedX = 200;
                    break;
                case 38: //上键
                case 87: //w
                    self.speedY = +200;
                    break;
                case 40: //下键
                case 83: //s
                    self.speedY = -200;
                    break;
                default:
                    break;
            }
        };
        var func2 = function (event) {
            // 判断输入的是哪个键
            switch (event.keyCode) {
                case 37: //左键
                case 65: //a
                    if (self.speedX < 0) {
                        self.speedX = 0;
                    }
                    break;
                case 39: //右键
                case 68: //d
                    if (self.speedX > 0) {
                        self.speedX = 0;
                    }
                    break;
                case 38: //上键
                case 87: //w
                    if (self.speedY > 0) {
                        self.speedY = 0;
                    }
                    break;
                case 40: //下键
                case 83: //s
                    if (self.speedY < 0) {
                        self.speedY = 0;
                    }
                    break;
                default:
                    break;
            }
        };
        //键盘监听函数
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, func1);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, func2);
    };
    Player.prototype.start = function () {
        //————————————————————飞机碰撞箱部分————————————————————
        cc.director.getCollisionManager().enabled = true;
    };
    //产生碰撞
    Player.prototype.onCollisionEnter = function (other) {
    };
    Player.prototype.update = function (dt) {
        //边框判定和实现X、Y轴位移
        if (((this.node.x >= -190) && (this.speedX < 0)) || ((this.node.x <= 190) && (this.speedX > 0))) {
            this.node.x += this.speedX * dt;
        }
        //Y轴与X轴同理
        if (((this.node.y >= -364) && (this.speedY < 0)) || ((this.node.y <= 364) && (this.speedY > 0))) {
            this.node.y += this.speedY * dt;
        }
    };
    Player.prototype.onDestroy = function () {
        //这里可能有问题
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP);
    };
    __decorate([
        property
    ], Player.prototype, "speedX", void 0);
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFBsYXllci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUFvQywwQkFBWTtJQUFoRDtRQUFBLHFFQTRHQztRQTFHRyxRQUFRO1FBRVIsWUFBTSxHQUFXLENBQUMsQ0FBQztRQUNuQixZQUFNLEdBQVcsQ0FBQyxDQUFDOztJQXVHdkIsQ0FBQztJQXJHRyx1QkFBTSxHQUFOO1FBRUksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLGtEQUFrRDtRQUNsRCxTQUFTO1FBQ1QsSUFBSSxLQUFLLEdBQUcsVUFBUyxLQUFLO1lBQ3RCLFlBQVk7WUFDWixRQUFRLEtBQUssQ0FBQyxPQUFPLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxDQUFDLENBQUEsSUFBSTtnQkFDWixLQUFLLEVBQUUsRUFBQyxHQUFHO29CQUNQLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLENBQUM7b0JBQ25CLE1BQU07Z0JBQ1YsS0FBSyxFQUFFLENBQUMsQ0FBQSxJQUFJO2dCQUNaLEtBQUssRUFBRSxFQUFDLEdBQUc7b0JBQ1AsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7b0JBQ2xCLE1BQU07Z0JBQ1YsS0FBSyxFQUFFLENBQUMsQ0FBQSxJQUFJO2dCQUNaLEtBQUssRUFBRSxFQUFDLEdBQUc7b0JBQ1AsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQztvQkFDdkIsTUFBTTtnQkFDTixLQUFLLEVBQUUsQ0FBQyxDQUFBLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEVBQUMsR0FBRztvQkFDUCxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDO29CQUNuQixNQUFNO2dCQUNWO29CQUNJLE1BQU07YUFDYjtRQUNMLENBQUMsQ0FBQTtRQUNELElBQUksS0FBSyxHQUFHLFVBQVMsS0FBSztZQUN0QixZQUFZO1lBQ1osUUFBUSxLQUFLLENBQUMsT0FBTyxFQUFFO2dCQUNuQixLQUFLLEVBQUUsQ0FBQyxDQUFBLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEVBQUMsR0FBRztvQkFDUCxJQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUNsQjt3QkFDSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztxQkFDbkI7b0JBQ0QsTUFBTTtnQkFDVixLQUFLLEVBQUUsQ0FBQyxDQUFBLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEVBQUMsR0FBRztvQkFDUCxJQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUNsQjt3QkFDSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztxQkFDbkI7b0JBQ0QsTUFBTTtnQkFDVixLQUFLLEVBQUUsQ0FBQyxDQUFBLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEVBQUMsR0FBRztvQkFDUCxJQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUNsQjt3QkFDSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztxQkFDbkI7b0JBQ0wsTUFBTTtnQkFDTixLQUFLLEVBQUUsQ0FBQyxDQUFBLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEVBQUMsR0FBRztvQkFDUCxJQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUNsQjt3QkFDSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztxQkFDbkI7b0JBQ0QsTUFBTTtnQkFDVjtvQkFDSSxNQUFNO2FBQ2I7UUFDTCxDQUFDLENBQUE7UUFDRCxRQUFRO1FBQ1IsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNELEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBQyxLQUFLLENBQUMsQ0FBQztJQUk3RCxDQUFDO0lBRUQsc0JBQUssR0FBTDtRQUNJLGlEQUFpRDtRQUNqRCxFQUFFLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztJQUVyRCxDQUFDO0lBRUQsTUFBTTtJQUNOLGlDQUFnQixHQUFoQixVQUFpQixLQUFLO0lBR3RCLENBQUM7SUFFRCx1QkFBTSxHQUFOLFVBQVEsRUFBRTtRQUVOLGVBQWU7UUFDZixJQUFHLENBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBRSxJQUFFLENBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFFLENBQUUsRUFDakc7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztTQUNuQztRQUNELFNBQVM7UUFDVCxJQUFHLENBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBRSxJQUFFLENBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFFLENBQUUsRUFDakc7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztTQUNuQztJQUNMLENBQUM7SUFDRCwwQkFBUyxHQUFUO1FBQ0ksU0FBUztRQUNULEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RELEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUF2R0Q7UUFEQyxRQUFROzBDQUNVO0lBSkYsTUFBTTtRQUQxQixPQUFPO09BQ2EsTUFBTSxDQTRHMUI7SUFBRCxhQUFDO0NBNUdELEFBNEdDLENBNUdtQyxFQUFFLENBQUMsU0FBUyxHQTRHL0M7a0JBNUdvQixNQUFNIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQbGF5ZXIgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gICAgLy/lrprkuYnpo57mnLrpgJ/luqZcbiAgICBAcHJvcGVydHlcbiAgICBzcGVlZFg6IG51bWJlciA9IDA7XG4gICAgc3BlZWRZOiBudW1iZXIgPSAwO1xuXG4gICAgb25Mb2FkICgpIFxuICAgIHtcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xuICAgICAgICAvL+KAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOmjnuacuuenu+WKqOmDqOWIhuKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlFxuICAgICAgICAvLyDorr7lrprlh73mlbDmk43kvZxcbiAgICAgICAgbGV0IGZ1bmMxID0gZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgICAgIC8vIOWIpOaWrei+k+WFpeeahOaYr+WTquS4qumUrlxuICAgICAgICAgICAgc3dpdGNoIChldmVudC5rZXlDb2RlKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAzNzovL+W3pumUrlxuICAgICAgICAgICAgICAgIGNhc2UgNjU6Ly9hXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc3BlZWRYID0gLTIwMDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAzOTovL+WPs+mUrlxuICAgICAgICAgICAgICAgIGNhc2UgNjg6Ly9kXG4gICAgICAgICAgICAgICAgICAgIHNlbGYuc3BlZWRYID0gMjAwO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDM4Oi8v5LiK6ZSuXG4gICAgICAgICAgICAgICAgY2FzZSA4NzovL3dcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5zcGVlZFkgPSArMjAwO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgNDA6Ly/kuIvplK5cbiAgICAgICAgICAgICAgICBjYXNlIDgzOi8vc1xuICAgICAgICAgICAgICAgICAgICBzZWxmLnNwZWVkWSA9IC0yMDA7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGxldCBmdW5jMiA9IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICAgICAgICAvLyDliKTmlq3ovpPlhaXnmoTmmK/lk6rkuKrplK5cbiAgICAgICAgICAgIHN3aXRjaCAoZXZlbnQua2V5Q29kZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgMzc6Ly/lt6bplK5cbiAgICAgICAgICAgICAgICBjYXNlIDY1Oi8vYVxuICAgICAgICAgICAgICAgICAgICBpZihzZWxmLnNwZWVkWCA8IDApXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc3BlZWRYID0gMDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDM5Oi8v5Y+z6ZSuXG4gICAgICAgICAgICAgICAgY2FzZSA2ODovL2RcbiAgICAgICAgICAgICAgICAgICAgaWYoc2VsZi5zcGVlZFggPiAwKVxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNwZWVkWCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAzODovL+S4iumUrlxuICAgICAgICAgICAgICAgIGNhc2UgODc6Ly93XG4gICAgICAgICAgICAgICAgICAgIGlmKHNlbGYuc3BlZWRZID4gMClcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zcGVlZFkgPSAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA0MDovL+S4i+mUrlxuICAgICAgICAgICAgICAgIGNhc2UgODM6Ly9zXG4gICAgICAgICAgICAgICAgICAgIGlmKHNlbGYuc3BlZWRZIDwgMClcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zcGVlZFkgPSAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8v6ZSu55uY55uR5ZCs5Ye95pWwXG4gICAgICAgIGNjLnN5c3RlbUV2ZW50Lm9uKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfRE9XTixmdW5jMSk7XG4gICAgICAgIGNjLnN5c3RlbUV2ZW50Lm9uKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfVVAsZnVuYzIpO1xuICAgICAgICBcblxuICAgICAgICBcbiAgICB9XG4gICAgXG4gICAgc3RhcnQgKCkge1xuICAgICAgICAvL+KAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOmjnuacuueisOaSnueusemDqOWIhuKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlOKAlFxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XG5cbiAgICB9XG5cbiAgICAvL+S6p+eUn+eisOaSnlxuICAgIG9uQ29sbGlzaW9uRW50ZXIob3RoZXIpXG4gICAge1xuICAgICAgICBcbiAgICB9XG5cbiAgICB1cGRhdGUgKGR0KSBcbiAgICB7XG4gICAgICAgIC8v6L655qGG5Yik5a6a5ZKM5a6e546wWOOAgVnovbTkvY3np7tcbiAgICAgICAgaWYoKCAodGhpcy5ub2RlLnggPj0gLTE5MCkgJiYgKHRoaXMuc3BlZWRYIDwgMCkgKXx8KCAodGhpcy5ub2RlLnggPD0gMTkwKSAmJiAodGhpcy5zcGVlZFggPiAwICkgKSlcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnggKz0gdGhpcy5zcGVlZFggKiBkdDtcbiAgICAgICAgfVxuICAgICAgICAvL1novbTkuI5Y6L205ZCM55CGXG4gICAgICAgIGlmKCggKHRoaXMubm9kZS55ID49IC0zNjQpICYmICh0aGlzLnNwZWVkWSA8IDApICl8fCggKHRoaXMubm9kZS55IDw9IDM2NCkgJiYgKHRoaXMuc3BlZWRZID4gMCApICkpXG4gICAgICAgIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS55ICs9IHRoaXMuc3BlZWRZICogZHQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgb25EZXN0cm95KCkge1xuICAgICAgICAvL+i/memHjOWPr+iDveaciemXrumimFxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vZmYoY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOKTtcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub2ZmKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfVVApO1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '400f2mhU+1C17E1JnemFmmk', 'Game');
// resources/script/Game.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameSetting = /** @class */ (function (_super) {
    __extends(GameSetting, _super);
    //编写类名
    function GameSetting() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.PreTitle = null;
        _this.PreButton = null;
        _this.PrePlayer = null;
        _this.PreEnemyManager = null;
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    GameSetting.prototype.onLoad = function () { };
    GameSetting.prototype.start = function () {
    };
    __decorate([
        property(cc.Prefab)
    ], GameSetting.prototype, "PreTitle", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameSetting.prototype, "PreButton", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameSetting.prototype, "PrePlayer", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameSetting.prototype, "PreEnemyManager", void 0);
    GameSetting = __decorate([
        ccclass
        //编写类名
    ], GameSetting);
    return GameSetting;
}(cc.Component));
exports.default = GameSetting;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFJMUM7SUFBeUMsK0JBQVk7SUFEckQsTUFBTTtJQUNOO1FBQUEscUVBd0JDO1FBckJHLGNBQVEsR0FBYSxJQUFJLENBQUM7UUFHMUIsZUFBUyxHQUFhLElBQUksQ0FBQztRQUczQixlQUFTLEdBQWEsSUFBSSxDQUFDO1FBRzNCLHFCQUFlLEdBQWEsSUFBSSxDQUFDOztRQVdqQyxpQkFBaUI7SUFDckIsQ0FBQztJQVRHLHdCQUF3QjtJQUV4Qiw0QkFBTSxHQUFOLGNBQVcsQ0FBQztJQUVaLDJCQUFLLEdBQUw7SUFFQSxDQUFDO0lBbEJEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7aURBQ007SUFHMUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztrREFDTztJQUczQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO2tEQUNPO0lBRzNCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7d0RBQ2E7SUFaaEIsV0FBVztRQUYvQixPQUFPO1FBQ1IsTUFBTTtPQUNlLFdBQVcsQ0F3Qi9CO0lBQUQsa0JBQUM7Q0F4QkQsQUF3QkMsQ0F4QndDLEVBQUUsQ0FBQyxTQUFTLEdBd0JwRDtrQkF4Qm9CLFdBQVciLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3Ncbi8v57yW5YaZ57G75ZCNXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHYW1lU2V0dGluZyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG5cbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxuICAgIFByZVRpdGxlOmNjLlByZWZhYiA9IG51bGw7XG4gICAgXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcbiAgICBQcmVCdXR0b246Y2MuUHJlZmFiID0gbnVsbDtcbiAgICBcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxuICAgIFByZVBsYXllcjpjYy5QcmVmYWIgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcbiAgICBQcmVFbmVteU1hbmFnZXI6Y2MuUHJlZmFiID0gbnVsbDtcblxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICBvbkxvYWQgKCkge31cblxuICAgIHN0YXJ0ICgpIHtcblxuICAgIH1cblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Background.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '66faaijs8FJWq06sY3lmKO0', 'Background');
// resources/script/Background.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Background = /** @class */ (function (_super) {
    __extends(Background, _super);
    function Background() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.y_velo = 40; //画布往下翻的速度
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    //被加载时
    Background.prototype.onLoad = function () { };
    //被加载后
    Background.prototype.start = function () {
    };
    //每一帧更新时
    Background.prototype.update = function (dt) {
        //定义背景往下翻的速率
        this.node.y -= 40 * dt;
        //如果往下翻的太多了，就搬回来，保证看起来连贯的效果
        if (this.node.y <= -852) {
            this.node.y = 0;
        }
    };
    __decorate([
        property
    ], Background.prototype, "y_velo", void 0);
    Background = __decorate([
        ccclass
    ], Background);
    return Background;
}(cc.Component));
exports.default = Background;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEJhY2tncm91bmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBd0MsOEJBQVk7SUFBcEQ7UUFBQSxxRUFzQkM7UUFuQkcsWUFBTSxHQUFVLEVBQUUsQ0FBQyxDQUFBLFVBQVU7O0lBbUJqQyxDQUFDO0lBbEJHLHdCQUF3QjtJQUN4QixNQUFNO0lBQ04sMkJBQU0sR0FBTixjQUFXLENBQUM7SUFDWixNQUFNO0lBQ04sMEJBQUssR0FBTDtJQUVBLENBQUM7SUFDRCxRQUFRO0lBQ1IsMkJBQU0sR0FBTixVQUFRLEVBQUU7UUFFTixZQUFZO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUN2QiwyQkFBMkI7UUFDM0IsSUFBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFDdEI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkI7SUFDTCxDQUFDO0lBbEJEO1FBREMsUUFBUTs4Q0FDVTtJQUhGLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0FzQjlCO0lBQUQsaUJBQUM7Q0F0QkQsQUFzQkMsQ0F0QnVDLEVBQUUsQ0FBQyxTQUFTLEdBc0JuRDtrQkF0Qm9CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEJhY2tncm91bmQgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gICAgQHByb3BlcnR5XG4gICAgeV92ZWxvOm51bWJlciA9IDQwOy8v55S75biD5b6A5LiL57+755qE6YCf5bqmXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG4gICAgLy/ooqvliqDovb3ml7ZcbiAgICBvbkxvYWQgKCkge31cbiAgICAvL+iiq+WKoOi9veWQjlxuICAgIHN0YXJ0ICgpIHtcblxuICAgIH1cbiAgICAvL+avj+S4gOW4p+abtOaWsOaXtlxuICAgIHVwZGF0ZSAoZHQpIFxuICAgIHtcbiAgICAgICAgLy/lrprkuYnog4zmma/lvoDkuIvnv7vnmoTpgJ/njodcbiAgICAgICAgdGhpcy5ub2RlLnkgLT0gNDAgKiBkdDtcbiAgICAgICAgLy/lpoLmnpzlvoDkuIvnv7vnmoTlpKrlpJrkuobvvIzlsLHmkKzlm57mnaXvvIzkv53or4HnnIvotbfmnaXov57otK/nmoTmlYjmnpxcbiAgICAgICAgaWYodGhpcy5ub2RlLnkgPD0gLTg1MilcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnkgPSAwO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Button.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '55e3fMGMCxOHalmCRKDP5Ex', 'Button');
// resources/script/Button.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Game_1 = require("./Game");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//设置类名，继承游戏设定类
var Button = /** @class */ (function (_super) {
    __extends(Button, _super);
    function Button() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // LIFE-CYCLE CALLBACKS:
    Button.prototype.onLoad = function () {
        var self = this;
        //设定函数操作
        var func1 = function (event) {
            var nodePlayer = cc.instantiate(self.PrePlayer);
            var nodeEnemyManager = cc.instantiate(self.PreEnemyManager);
            var Parent = cc.find("Canvas/Main Camera");
            var Title = cc.find("Canvas/Main Camera/Title");
            nodePlayer.setParent(Parent);
            nodeEnemyManager.setParent(Parent);
            Parent.removeChild(Title);
            self.node.removeFromParent();
        };
        this.node.on(cc.Node.EventType.MOUSE_UP, func1);
    };
    Button.prototype.start = function () {
    };
    Button.prototype.update = function (dt) { };
    Button.prototype.onDestroy = function () {
        //这里可能有问题
        this.node.off(cc.Node.EventType.MOUSE_UP);
    };
    Button = __decorate([
        ccclass
    ], Button);
    return Button;
}(Game_1.default));
exports.default = Button;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEJ1dHRvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrQkFBaUM7QUFFM0IsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFDMUMsY0FBYztBQUVkO0lBQW9DLDBCQUFXO0lBQS9DOztJQStCQSxDQUFDO0lBN0JHLHdCQUF3QjtJQUV4Qix1QkFBTSxHQUFOO1FBRUksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLFFBQVE7UUFDUixJQUFJLEtBQUssR0FBRyxVQUFTLEtBQUs7WUFDdEIsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDaEQsSUFBSSxnQkFBZ0IsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUM1RCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDM0MsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1lBQ2hELFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDN0IsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ25DLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBRWpDLENBQUMsQ0FBQTtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsc0JBQUssR0FBTDtJQUVBLENBQUM7SUFFRCx1QkFBTSxHQUFOLFVBQVEsRUFBRSxJQUFHLENBQUM7SUFDZCwwQkFBUyxHQUFUO1FBQ0ksU0FBUztRQUNULElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUE5QmdCLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0ErQjFCO0lBQUQsYUFBQztDQS9CRCxBQStCQyxDQS9CbUMsY0FBVyxHQStCOUM7a0JBL0JvQixNQUFNIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEdhbWVTZXR0aW5nIGZyb20gXCIuL0dhbWVcIjtcblxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XG4vL+iuvue9ruexu+WQje+8jOe7p+aJv+a4uOaIj+iuvuWumuexu1xuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEJ1dHRvbiBleHRlbmRzIEdhbWVTZXR0aW5nIHtcblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkICgpIFxuICAgIHtcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xuICAgICAgICAvL+iuvuWumuWHveaVsOaTjeS9nFxuICAgICAgICBsZXQgZnVuYzEgPSBmdW5jdGlvbihldmVudCkge1xuICAgICAgICAgICAgbGV0IG5vZGVQbGF5ZXIgPSBjYy5pbnN0YW50aWF0ZShzZWxmLlByZVBsYXllcik7XG4gICAgICAgICAgICBsZXQgbm9kZUVuZW15TWFuYWdlciA9IGNjLmluc3RhbnRpYXRlKHNlbGYuUHJlRW5lbXlNYW5hZ2VyKTtcbiAgICAgICAgICAgIGxldCBQYXJlbnQgPSBjYy5maW5kKFwiQ2FudmFzL01haW4gQ2FtZXJhXCIpO1xuICAgICAgICAgICAgbGV0IFRpdGxlID0gY2MuZmluZChcIkNhbnZhcy9NYWluIENhbWVyYS9UaXRsZVwiKTtcbiAgICAgICAgICAgIG5vZGVQbGF5ZXIuc2V0UGFyZW50KFBhcmVudCk7XG4gICAgICAgICAgICBub2RlRW5lbXlNYW5hZ2VyLnNldFBhcmVudChQYXJlbnQpO1xuICAgICAgICAgICAgUGFyZW50LnJlbW92ZUNoaWxkKFRpdGxlKTtcbiAgICAgICAgICAgIHNlbGYubm9kZS5yZW1vdmVGcm9tUGFyZW50KCk7XG5cbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfVVAsZnVuYzEpO1xuICAgIH1cblxuICAgIHN0YXJ0ICgpIHtcblxuICAgIH1cblxuICAgIHVwZGF0ZSAoZHQpIHt9XG4gICAgb25EZXN0cm95KCkge1xuICAgICAgICAvL+i/memHjOWPr+iDveaciemXrumimFxuICAgICAgICB0aGlzLm5vZGUub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX1VQKTtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/EnemyManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8cc932PfehIkIA4aGg3e8Ob', 'EnemyManager');
// resources/script/EnemyManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var EnemyManager = /** @class */ (function (_super) {
    __extends(EnemyManager, _super);
    function EnemyManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.PreEnemy = null;
        _this.text = 'hello';
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    EnemyManager.prototype.start = function () {
        var _this = this;
        this.schedule(function () {
            //创建敌机
            var Enemy = cc.instantiate(_this.PreEnemy);
            Enemy.setParent(cc.find("Canvas/Main Camera"));
            Enemy.y = _this.node.y;
            Enemy.x = (Math.random() - 0.5) * 400 + 20;
        }, 2);
    };
    __decorate([
        property(cc.Prefab)
    ], EnemyManager.prototype, "PreEnemy", void 0);
    __decorate([
        property
    ], EnemyManager.prototype, "text", void 0);
    EnemyManager = __decorate([
        ccclass
    ], EnemyManager);
    return EnemyManager;
}(cc.Component));
exports.default = EnemyManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVuZW15TWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUEwQyxnQ0FBWTtJQUF0RDtRQUFBLHFFQTBCQztRQXZCRyxjQUFRLEdBQWMsSUFBSSxDQUFDO1FBRzNCLFVBQUksR0FBVyxPQUFPLENBQUM7O1FBbUJ2QixpQkFBaUI7SUFDckIsQ0FBQztJQWxCRyx3QkFBd0I7SUFFeEIsZUFBZTtJQUVmLDRCQUFLLEdBQUw7UUFBQSxpQkFXQztRQVZHLElBQUksQ0FBQyxRQUFRLENBQUM7WUFFVixNQUFNO1lBQ04sSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDMUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztZQUMvQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3RCLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQztRQUc3QyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDVCxDQUFDO0lBcEJEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7a0RBQ087SUFHM0I7UUFEQyxRQUFROzhDQUNjO0lBTk4sWUFBWTtRQURoQyxPQUFPO09BQ2EsWUFBWSxDQTBCaEM7SUFBRCxtQkFBQztDQTFCRCxBQTBCQyxDQTFCeUMsRUFBRSxDQUFDLFNBQVMsR0EwQnJEO2tCQTFCb0IsWUFBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgRW5lbXlNYW5hZ2VyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXG4gICAgUHJlRW5lbXk6IGNjLlByZWZhYiA9IG51bGw7XG5cbiAgICBAcHJvcGVydHlcbiAgICB0ZXh0OiBzdHJpbmcgPSAnaGVsbG8nO1xuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICAvLyBvbkxvYWQgKCkge31cblxuICAgIHN0YXJ0ICgpIHtcbiAgICAgICAgdGhpcy5zY2hlZHVsZSgoKT0+XG4gICAgICAgIHtcbiAgICAgICAgICAgIC8v5Yib5bu65pWM5py6XG4gICAgICAgICAgICBsZXQgRW5lbXkgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLlByZUVuZW15KTtcbiAgICAgICAgICAgIEVuZW15LnNldFBhcmVudChjYy5maW5kKFwiQ2FudmFzL01haW4gQ2FtZXJhXCIpKTtcbiAgICAgICAgICAgIEVuZW15LnkgPSB0aGlzLm5vZGUueTtcbiAgICAgICAgICAgIEVuZW15LnggPSAoTWF0aC5yYW5kb20oKS0wLjUpICogNDAwICsgMjA7XG5cblxuICAgICAgICB9LDIpO1xuICAgIH1cblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------
