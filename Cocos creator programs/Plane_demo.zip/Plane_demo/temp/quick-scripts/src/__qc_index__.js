
require('./assets/resources/script/Background');
require('./assets/resources/script/Button');
require('./assets/resources/script/EnemyManager');
require('./assets/resources/script/Game');
require('./assets/resources/script/Player');
