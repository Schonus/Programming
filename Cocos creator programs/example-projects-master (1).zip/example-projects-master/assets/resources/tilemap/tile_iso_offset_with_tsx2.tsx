<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tile_iso_offset_with_tsx2" tilewidth="101" tileheight="101" tilecount="2" columns="1">
 <image source="tile_iso_offset_with_tsx2.png" width="101" height="202"/>
</tileset>
