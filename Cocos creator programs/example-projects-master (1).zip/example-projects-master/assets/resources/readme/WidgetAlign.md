## Widget 基础对齐功能使用说明

1. 依次点击场景中 align_left, align_right, align_top, align_bottom 四个 sprite，确认他们的位置
2. 拖拽修改 Scene 面板上方的设计分辨率，可以看到四个 sprite 依然紧贴四条边对齐
3. 在 align_left 的节点 Widget 组件里，修改 Left 对齐下方的偏移值，可以看到 align_left 和场景最左边的距离发生变化
4. 再次修改 Scene 面板上的设计分辨率，align_left 将和屏幕左边保持刚刚设定的偏移距离