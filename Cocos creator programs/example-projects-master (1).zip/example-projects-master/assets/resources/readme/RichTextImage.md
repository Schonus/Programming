## RichText 支持图片功能展示

1. 设置 RichText 组件中的 imageAtlas
2. 添加`<img src="图片名称">` 标签
