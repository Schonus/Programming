## Tiled Sprite 使用说明

1. 场景正中显示是由tiled Sprite 类型的sprite 组合而成的 进度条.
2. Sprite 组件里的 Type 属性应设为 Tiled. 
3. 设置Anchor 可以控制进度条的朝向.
4. 设置Size的width 控制进度条的进度.