## 代码与资源分包的展示

必须要先通过 API: `cc.loader.downloader.loadSubpackage` 进行加载子包资源，才能够成功进入子包场景

注意：范例中必须要有配置为子包的文件资源