## RichText 基础功能展示

1. 使用了 color、size、outline 等各类标签功能
2. 展示了手动换行和自动换行的展示

注意：目前原生平台暂不支持 RichText 的描边