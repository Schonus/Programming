import { _decorator, Component, Node, Enum } from "cc";

export enum PanelType {
  Home = -1,
  Shop = -1,
};

Enum(PanelType);
